﻿package dev.aurakai.auraframefx.oracle.drive.api

/**
 * Placeholder implementation of OracleDriveApi for build compatibility
 */
interface OracleDriveApi {
    // Add Oracle Drive API methods as needed
}
