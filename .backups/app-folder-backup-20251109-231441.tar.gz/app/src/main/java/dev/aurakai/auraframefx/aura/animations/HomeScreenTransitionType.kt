﻿package dev.aurakai.auraframefx.system.homescreen

enum class HomeScreenTransitionType {
    DIGITAL_DECONSTRUCT,
    HOLOGRAM,
    PIXELATE
}
