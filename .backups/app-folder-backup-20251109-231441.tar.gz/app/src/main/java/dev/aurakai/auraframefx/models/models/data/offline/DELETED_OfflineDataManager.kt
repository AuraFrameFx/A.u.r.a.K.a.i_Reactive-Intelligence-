﻿package dev.aurakai.auraframefx.data.offline

class OfflineDataManager {
    // Stub implementation
}

