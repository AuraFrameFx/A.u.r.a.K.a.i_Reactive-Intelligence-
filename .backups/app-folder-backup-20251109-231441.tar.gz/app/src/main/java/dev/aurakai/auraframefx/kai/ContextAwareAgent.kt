﻿package dev.aurakai.auraframefx.kai

interface ContextAwareAgent {
    fun setContext(context: Map<String, Any>)
}
