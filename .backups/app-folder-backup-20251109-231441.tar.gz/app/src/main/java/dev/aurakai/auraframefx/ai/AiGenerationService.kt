﻿package dev.aurakai.auraframefx.ai

// import dev.aurakai.auraframefx.generated.model.auraframefxai.GenerateImageDescriptionResponse // Not available in new API
// import kotlinx.coroutines.CoroutineScope // Not needed if generateImageDescription is removed
import dev.aurakai.auraframefx.ai.model.GenerateTextRequest
import dev.aurakai.auraframefx.ai.model.GenerateTextResponse
import dev.aurakai.auraframefx.api.AiContentApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AiGenerationService(
    private val api: AiContentApi, // Updated type
) {
    suspend fun generateText(
        prompt: String,
        maxTokens: Int = 500,
        temperature: Float = 0.7f,
    ): Result<GenerateTextResponse> = withContext(Dispatchers.IO) {
        try {
            val request = GenerateTextRequest( // This will now use the new model
                prompt = prompt,
                maxTokens = maxTokens,
                temperature = temperature
            )
            val response = api.generateText(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
