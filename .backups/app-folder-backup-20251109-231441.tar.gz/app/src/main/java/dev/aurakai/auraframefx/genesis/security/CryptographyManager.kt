package dev.aurakai.auraframefx.genesis.security

/**
 * Placeholder implementation of CryptographyManager for build compatibility
 */
class CryptographyManager {
    fun encrypt(data: String): String = data
    fun decrypt(data: String): String = data
}
