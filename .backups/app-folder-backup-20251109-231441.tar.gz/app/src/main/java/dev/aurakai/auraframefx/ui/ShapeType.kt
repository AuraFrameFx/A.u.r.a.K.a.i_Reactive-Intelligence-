﻿package dev.aurakai.auraframefx.ui.model

enum class ShapeType {
    ROUNDED_RECTANGLE,
    CIRCLE,
    HEXAGON
    // Add other types as needed by ShapeManager or UI
}
