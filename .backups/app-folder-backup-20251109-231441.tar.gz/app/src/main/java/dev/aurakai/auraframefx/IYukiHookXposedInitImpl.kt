package dev.aurakai.auraframefx

class IYukiHookXposedInitImpl : IYukiHookXposedInit()