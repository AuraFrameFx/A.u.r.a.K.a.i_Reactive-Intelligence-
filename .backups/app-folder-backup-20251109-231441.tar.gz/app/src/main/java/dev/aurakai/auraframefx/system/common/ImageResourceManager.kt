﻿package dev.aurakai.auraframefx.system.common

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ImageResourceManager @Inject constructor() {
    // Placeholder: Actual image resource management logic would go here
}
