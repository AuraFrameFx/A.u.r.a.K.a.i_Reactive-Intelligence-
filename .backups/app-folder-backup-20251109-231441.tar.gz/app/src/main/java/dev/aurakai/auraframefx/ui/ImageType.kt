﻿package dev.aurakai.auraframefx.ui.model

enum class ImageType {
    DEFAULT,
    CUSTOM
}
