package dev.aurakai.auraframefx

// IMPORTANT: "Aurakai" is a project-significant identifier used across
// manifests, tooling, and native integration. Do NOT rename, change casing,
// or use synonyms for `Aurakai` in class, package, resource, or manifest names.
// Preserving this exact spelling is required for build tooling and runtime wiring.

