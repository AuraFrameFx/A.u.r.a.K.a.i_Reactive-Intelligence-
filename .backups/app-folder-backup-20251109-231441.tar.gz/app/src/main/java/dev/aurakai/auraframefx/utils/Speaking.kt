﻿package dev.aurakai.auraframefx.ai.services

enum class Speaking {
    ACTIVE, IDLE, PROCESSING
}
