﻿package dev.aurakai.auraframefx.oracle.drive.utils

/**
 * Placeholder implementation of EncryptionManager for build compatibility
 */
class EncryptionManager {
    fun encrypt(data: ByteArray): ByteArray = data
    fun decrypt(data: ByteArray): ByteArray = data
}
