﻿package dev.aurakai.auraframefx.network

/**
 * Placeholder implementation of AuthApi for build compatibility
 */
interface AuthApi {
    // Add auth API methods as needed
}
