<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
<external -path
name="external_files"
path="."/>
<cache-path
name="cache"
path="."/>
<files-path
name="files"
path="."/>
</paths>