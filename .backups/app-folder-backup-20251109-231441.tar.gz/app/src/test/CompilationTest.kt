﻿package dev.aurakai.auraframefx.test

/**
 * Simple test class to check if basic compilation works
 */
class CompilationTest {
    fun simpleTest(): String {
        return "Hello World"
    }
}
